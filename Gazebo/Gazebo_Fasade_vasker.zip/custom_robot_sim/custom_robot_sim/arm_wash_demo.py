#!/usr/bin/env python3
import math
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray


class ArmWashDemo(Node):
    def __init__(self):
        super().__init__('arm_wash_demo')

        # Publisher to the arm controller
        self.pub = self.create_publisher(
            Float64MultiArray,
            '/robot_arm_controller/commands',
            10
        )

        # Joint order: [arm_base, arm_link_2, arm_link_3, head_pitch, head_yaw]
        self.current_cmd = [0.0, 0.2, -0.8, 0.0, 0.0]

        # Desired global nozzle orientation (spray direction)
        # yaw = 0.0  -> straight forward
        # pitch < 0  -> pointing slightly down
        self.desired_yaw = 0.0          # keep pointing forward
        self.desired_pitch = -0.25      # slight downward tilt

        # Vertical “wash levels” (link_2, link_3 joint targets)
        # Tune these if your arm looks weird or hits limits.
        self.levels = [
            (0.20, -0.80),
            (0.55, -0.50),
            (0.85, -0.25),
            (1.05, -0.05),
        ]
        self.level_index = 0

        # Horizontal sweep config
        self.base_left = -0.6
        self.base_right = 0.6
        self.sweep_steps = 300          # steps per horizontal sweep
        self.step_count = 0
        self.direction = 1              # +1: left->right, -1: right->left
        self.just_changed_level = False

        # How fast to move joints vertically
        self.vertical_step_size = 0.008

        # Timer at 20 Hz
        self.timer = self.create_timer(0.05, self.update)

    # ---------- Helper: smoothly move l2/l3 towards target level ----------
    def move_links_to_level(self):
        target_l2, target_l3 = self.levels[self.level_index]

        # indices 1 and 2 are arm_link_2 and arm_link_3
        for i, target in [(1, target_l2), (2, target_l3)]:
            diff = target - self.current_cmd[i]
            if abs(diff) > self.vertical_step_size:
                self.current_cmd[i] += self.vertical_step_size * (1.0 if diff > 0 else -1.0)
            else:
                self.current_cmd[i] = target

    # ---------- Keep nozzle pointed same direction ----------
    def lock_nozzle_direction(self):
        base = self.current_cmd[0]
        l2   = self.current_cmd[1]
        l3   = self.current_cmd[2]

        # Overall yaw: base + head_yaw = desired_yaw
        head_yaw = self.desired_yaw - base

        # Overall pitch: l2 + l3 + head_pitch = desired_pitch
        head_pitch = self.desired_pitch - (l2 + l3)

        # Clamp within joint limits (±pi/2 from your config)
        head_yaw   = max(-math.pi/2, min(math.pi/2, head_yaw))
        head_pitch = max(-math.pi/2, min(math.pi/2, head_pitch))

        self.current_cmd[3] = head_pitch
        self.current_cmd[4] = head_yaw

    # ---------- Main update loop ----------
    def update(self):
        # 1) Horizontal sweep: base joint moves left<->right with triangular wave
        phase = (self.step_count % self.sweep_steps) / float(self.sweep_steps)  # 0..1
        if self.direction == 1:
            # left -> right
            base = self.base_left + (self.base_right - self.base_left) * phase
        else:
            # right -> left
            base = self.base_right + (self.base_left - self.base_right) * phase

        self.current_cmd[0] = base

        # 2) Move link_2 and link_3 smoothly to the current vertical level
        self.move_links_to_level()

        # 3) At the end of a sweep, change level and direction
        #    We detect "near the end" of the sweep using phase > 0.99
        if phase > 0.99 and not self.just_changed_level:
            # Move to next level
            self.level_index += 1
            if self.level_index >= len(self.levels):
                # If we passed the last level, wrap back to top
                self.level_index = 0
            # Flip sweep direction
            self.direction *= -1
            self.just_changed_level = True

        # Reset the "edge detector" when we're back near the start of a sweep
        if phase < 0.1:
            self.just_changed_level = False

        # Step counter always increases
        self.step_count += 1

        # 4) Keep nozzle/orientation constant
        self.lock_nozzle_direction()

        # 5) Publish command
        msg = Float64MultiArray()
        msg.data = self.current_cmd
        self.pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = ArmWashDemo()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
