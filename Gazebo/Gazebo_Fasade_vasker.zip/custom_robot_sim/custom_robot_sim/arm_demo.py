#!/usr/bin/env python3
import math
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray

class ArmWashDemo(Node):
    def __init__(self):
        super().__init__('arm_wash_demo')

        self.pub = self.create_publisher(
            Float64MultiArray,
            '/robot_arm_controller/commands',
            10
        )

        # Command format: [base, link2, link3, head_pitch, head_yaw]
        self.current_cmd = [0.0, 0.2, -0.8, 0.0, 0.0]

        # Desired nozzle direction (keeps head steady)
        self.desired_yaw = 0.0          # keep pointing forward
        self.desired_pitch = -0.2       # slight down angle like pressure washer

        self.level = 0                  # current vertical "wash level"
        self.phase = 0                  # motion state machine
        self.step  = 0                  # incremental counter

        self.max_levels = 5             # how many vertical drops before stop
        self.timer = self.create_timer(0.05, self.update)  # 20Hz

    # ---------------------------------------
    # Keep nozzle pointed constant direction
    # ---------------------------------------
    def lock_nozzle_direction(self):
        base, l2, l3 = self.current_cmd[:3]

        head_yaw   = self.desired_yaw - base
        head_pitch = self.desired_pitch - (l2 + l3)

        # Clamp inside joint limits
        head_yaw   = max(-math.pi/2, min(math.pi/2, head_yaw))
        head_pitch = max(-math.pi/2, min(math.pi/2, head_pitch))

        self.current_cmd[3] = head_pitch
        self.current_cmd[4] = head_yaw

    # ---------------------------------------
    # Run the Sweep Pattern
    # ---------------------------------------
    def update(self):

        # Height levels (top → bottom)
        heights = [
            (0.2, -0.8),
            (0.6, -0.4),
            (0.9, -0.2),
            (1.1,  0.0),
            (1.3,  0.1),
        ]

        # Extract this level's link2 + link3 targets
        link2_target, link3_target = heights[self.level]

        # ==================== PHASES =====================
        if self.phase == 0:   # Sweep Right →
            base = 0.8 * (self.step / 200)     # 0 → 0.8 rad
            self.current_cmd[0] = base
            self.current_cmd[1] = link2_target
            self.current_cmd[2] = link3_target
            self.step += 1
            if self.step > 200:
                self.phase = 1
                self.step  = 0

        elif self.phase == 1: # Drop Down ↓
            if self.level < self.max_levels - 1:
                self.level += 1
                self.phase = 2
            else:
                self.phase = 99  # finished

        elif self.phase == 2: # Sweep Left ←
            base = 0.8 - 1.6 * (self.step / 200)   # 0.8 → -0.8
            self.current_cmd[0] = base
            self.current_cmd[1] = link2_target
            self.current_cmd[2] = link3_target
            self.step += 1
            if self.step > 200:
                self.phase = 3
                self.step  = 0

        elif self.phase == 3: # Drop Down ↓
            if self.level < self.max_levels - 1:
                self.level += 1
                self.phase = 0
            else:
                self.phase = 99

        elif self.phase == 99:
            self.get_logger().info("🏁 Wash complete.")
            pass

        # Keep spray direction fixed
        self.lock_nozzle_direction()

        # Publish the movement
        msg = Float64MultiArray()
        msg.data = self.current_cmd
        self.pub.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = ArmWashDemo()
    rclpy.spin(node)

if __name__ == '__main__':
    main()
